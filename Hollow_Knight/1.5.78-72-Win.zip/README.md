Hollow Knight Modding API
=========================

This is a simple modding API used mainly for compatibility between mods. It does little on its own, but is required for several mods to run.

How To Install
==============

Navigate to your Hollow Knight Game Install folder.

    Steam: C:\Program Files (x86)\Steam\steamapps\common\Hollow Knight\
    GoG:

Copy everything in this zip file into the game's folder.  When prompted to overwrite files, say yes.

You may also use [Scarab](https://github.com/fifty-six/Scarab/releases/latest).

How To Uninstall
================

Steam: Right Click on Hollow Knight -> Properties -> Local Files -> Verify Integrity of Game Files
GoG: Options -> Manage Installation -> Verify / Repair
